import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-radar',
  templateUrl: './radar.component.html',
  styleUrls: ['./radar.component.less']
})
export class RadarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
