import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-real',
  templateUrl: './real.component.html',
  styleUrls: ['./real.component.less']
})
export class RealComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
