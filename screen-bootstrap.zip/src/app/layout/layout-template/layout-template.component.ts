import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-layout-template',
  templateUrl: './layout-template.component.html',
  styleUrls: ['./layout-template.component.less']
})
export class LayoutTemplateComponent implements OnInit {
  constructor() { }

  ngOnInit() {
  }

}
